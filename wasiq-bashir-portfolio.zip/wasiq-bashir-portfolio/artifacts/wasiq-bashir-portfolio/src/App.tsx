import { type FormEvent, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ArrowDown, ArrowUpRight, BookOpen, Braces, Check, Cloud, Code2, Container, Cpu, Database, Github, GitBranch, Globe2, Instagram, Layers, Linkedin, Menu, Send, Server, Terminal, X } from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import '@/index.css';

const queryClient = new QueryClient();
const portrait = '/wasiq-portrait.png';
const stairs = '/wasiq-stairs.png';
const tree = '/wasiq-tree.png';
const redPhoto = '/wasiq-red.jpg';

function useReveal<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setVisible(true);
        observer.disconnect();
      }
    }, { threshold: 0.12 });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  return { ref, className: `reveal${visible ? ' is-visible' : ''}` };
}

function usePointerScene() {
  useEffect(() => {
    const onMove = (event: MouseEvent) => {
      const x = `${event.clientX}px`;
      const y = `${event.clientY}px`;
      document.documentElement.style.setProperty('--px', `${(event.clientX - window.innerWidth / 2) / 20}px`);
      document.documentElement.style.setProperty('--py', `${(event.clientY - window.innerHeight / 2) / 20}px`);
      document.documentElement.style.setProperty('--mx', `${(event.clientX / window.innerWidth) * 100}%`);
      document.documentElement.style.setProperty('--my', `${(event.clientY / window.innerHeight) * 100}%`);
      document.documentElement.style.setProperty('--cursor-x', x);
      document.documentElement.style.setProperty('--cursor-y', y);
    };
    const onScroll = () => {
      document.documentElement.style.setProperty('--scroll-y', `${window.scrollY}px`);
      document.documentElement.style.setProperty('--scroll-x', `${Math.min(340, window.scrollY * 0.12)}px`);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('scroll', onScroll); };
  }, []);
}

function Intro({ onComplete }: { onComplete: () => void }) {
  const [percent, setPercent] = useState(0);
  useEffect(() => {
    const timer = window.setInterval(() => setPercent((current) => Math.min(100, current + 4)), 80);
    const done = window.setTimeout(onComplete, 2500);
    return () => { window.clearInterval(timer); window.clearTimeout(done); };
  }, [onComplete]);
  return (
    <div className="intro" aria-label="Loading Wasiq Bashir portfolio">
      <div className="intro-inner">
        <div className="intro-mark display">WB</div>
        <div className="intro-meta mono"><span>Software engineering</span><span>2026</span></div>
        <div className="intro-line"><span /></div>
        <div className="intro-count mono">{String(percent).padStart(3, '0')} / 100</div>
      </div>
    </div>
  );
}

function Cursor() {
  const [label, setLabel] = useState('');
  useEffect(() => {
    const update = (event: Event) => {
      const target = event.target as HTMLElement;
      const value = target.closest('[data-cursor]')?.getAttribute('data-cursor') ?? '';
      setLabel(value);
    };
    document.addEventListener('mouseover', update);
    return () => document.removeEventListener('mouseover', update);
  }, []);
  return <><div className="cursor" style={{ left: 'var(--cursor-x)', top: 'var(--cursor-y)' }} /><div className="cursor-label" style={{ left: 'var(--cursor-x)', top: 'var(--cursor-y)' }}>{label}</div></>;
}

function Header() {
  const [open, setOpen] = useState(false);
  const items = useMemo(() => [['about', 'About'], ['building', 'Building'], ['work', 'Work'], ['journey', 'Journey'], ['contact', 'Contact']], []);
  return (
    <header className="topbar">
      <a href="#top" className="brand" data-cursor="LINK" data-testid="link-brand"><b>W</b>ASIQ / BASHIR</a>
      <button className="nav-toggle" onClick={() => setOpen((value) => !value)} aria-label={open ? 'Close navigation' : 'Open navigation'} aria-expanded={open} data-testid="button-mobile-navigation">
        {open ? <X size={18} /> : <Menu size={18} />}
      </button>
      <nav className={`nav${open ? ' open' : ''}`} aria-label="Primary navigation">
        {items.map(([href, label]) => <a href={`#${href}`} key={href} onClick={() => setOpen(false)} data-cursor="LINK" data-testid={`link-nav-${href}`}>{label}</a>)}
      </nav>
    </header>
  );
}

function Hero() {
  return (
    <section className="hero" id="top" aria-labelledby="hero-title">
      <Header />
      <div className="hero-copy">
        <div className="hero-kicker eyebrow">Software engineering / Lahore / Pakistan</div>
        <h1 id="hero-title" className="display"><span><i>Wasiq</i></span><span><i>Bashir</i></span></h1>
        <div className="hero-sub">
          <p>Building from code fundamentals toward scalable software, cloud, and DevOps.</p>
          <div className="hero-roles"><span>Software engineering student</span><span>Aspiring cloud &amp; DevOps engineer</span></div>
        </div>
      </div>
      <div className="hero-photo-wrap" data-cursor="VIEW">
        <img className="hero-photo" src={portrait} alt="Wasiq Bashir, software engineering student" fetchPriority="high" />
      </div>
      <div className="hero-orbit" aria-hidden="true" />
      <a href="#about" className="scroll-hint" data-cursor="LINK" data-testid="link-scroll-about">Scroll to enter <ArrowDown size={13} /></a>
    </section>
  );
}

const gallery = [
  { type: 'image', src: stairs, alt: 'Wasiq Bashir in an atmospheric interior', label: '01 / perspective' },
  { type: 'abstract', label: '02 / systems thinking' },
  { type: 'image', src: tree, alt: 'Wasiq Bashir outdoors', label: '03 / in progress' },
  { type: 'abstract', label: '04 / code to cloud' },
  { type: 'image', src: redPhoto, alt: 'Wasiq Bashir in a red shirt', label: '05 / point of view' },
];

function GalleryTile({ item }: { item: typeof gallery[number] }) {
  if (item.type === 'abstract') return <div className="gallery-tile abstract-tile"><b>{item.label}</b><div className="tile-shade"><span>Learning is a system.</span></div></div>;
  return <div className="gallery-tile"><img src={item.src} alt={item.alt} loading="lazy" /><div className="tile-shade"><span>{item.label}</span></div></div>;
}

function Gallery() {
  return (
    <section className="marquee-section" aria-label="Visual introduction">
      <div className="marquee-intro">
        <div><div className="section-label">A visual index</div><h2 className="display">Not a résumé.<br />A direction.</h2></div>
        <p>Every project is a marker. Every experiment makes the next system easier to see.</p>
      </div>
      <div className="marquee-row forward">{[...gallery, ...gallery].map((item, index) => <GalleryTile item={item} key={`forward-${index}`} />)}</div>
      <div className="marquee-row reverse">{[...gallery.slice().reverse(), ...gallery].map((item, index) => <GalleryTile item={item} key={`reverse-${index}`} />)}</div>
    </section>
  );
}

const aboutCopy = "I'm a Software Engineering student building my foundations across programming, web development, systems, cloud computing and DevOps. I enjoy turning what I learn into practical projects, experimenting with technology, and continuously expanding the way I think about software and systems.";

function About() {
  const reveal = useReveal<HTMLElement>();
  const words = aboutCopy.split(' ');
  return (
    <section className="about" id="about" ref={reveal.ref} aria-labelledby="about-title">
      <div className="about-heading"><div><div className="section-label">02 / orientation</div><h2 id="about-title" className={`display ${reveal.className}`}>About<br />me</h2></div><p className="mono reveal delay-2">A student in Lahore, learning in public and building with intent.</p></div>
      <div className="about-grid">
        <div>
          <p className="about-statement display reveal delay-1">Building today.<br />Engineering tomorrow.</p>
          <p className="about-text reveal delay-2" data-testid="text-about-description">{words.map((word, index) => <span key={`${word}-${index}`} style={{ opacity: `${Math.min(1, .48 + index / words.length * .52)}` }}> {word}</span>)}</p>
        </div>
        <figure className="about-photo-frame reveal delay-3"><img src={stairs} alt="Wasiq Bashir standing on a staircase" loading="lazy" /><figcaption>Natural light / Lahore</figcaption></figure>
      </div>
    </section>
  );
}

const capabilities = [
  ['01', 'Programming', 'C++ / C# / JavaScript', Code2],
  ['02', 'Web development', 'HTML / CSS / JavaScript / DOM / responsive design', Globe2],
  ['03', 'Software engineering', 'OOP / DSA / problem solving / Git & GitHub', Braces],
  ['04', 'Systems', 'Databases / backend / Linux', Server],
  ['05', 'Cloud', 'Cloud computing / DevOps / infrastructure', Cloud],
] as const;

function Building() {
  return (
    <section className="light-section" id="building" aria-labelledby="building-title">
      <div className="section-label">03 / areas in motion</div>
      <h2 id="building-title" className="display">What I'm<br />building</h2>
      <div className="capability-list">{capabilities.map(([number, title, detail, Icon]) => <div className="capability" tabIndex={0} key={number} data-cursor="EXPLORE"><span className="num mono">{number}</span><div><h3>{title}</h3><p>{detail}</p></div><Icon className="arrow" size={23} /></div>)}</div>
      <p className="learning-note">These are learning areas and explorations — not claims of professional expertise.</p>
    </section>
  );
}

type Project = { number: string; category: string; title: string; description: string; tags: string[]; url: string; label?: string };
const projects: Project[] = [
  { number: '01', category: 'Web experience / selected work', title: 'Momenta', description: 'A premium digital celebration studio exploring responsive editorial layout, filtering, modals, configuration, pricing, FAQs, and accessible calls to action.', tags: ['HTML', 'CSS', 'Vanilla JavaScript'], url: 'https://github.com/cyber-Horcrux/My-Project' },
  { number: '02', category: 'Educational UI recreation', title: 'Netflix UI Clone', description: 'A responsive interface study built around hierarchy, hero composition, navigation, content sections, and a considered footer. Not affiliated with Netflix.', tags: ['HTML', 'CSS', 'Flexbox', 'CSS Grid'], url: 'https://github.com/cyber-Horcrux/netflix-ui-clone', label: 'Educational UI recreation' },
  { number: '03', category: 'Interaction study', title: 'JavaScript DOM Playground', description: 'A hands-on space for DOM manipulation, events, forms, timers, keyboard input, validation, and theme switching.', tags: ['JavaScript', 'DOM', 'Events'], url: 'https://github.com/cyber-Horcrux/javascript-dom-playground' },
  { number: '04', category: 'Practice / foundations', title: 'JavaScript Practice Toolkit', description: 'Small interactive exercises for functions, conditions, DOM work, events, validation, and the repetition that makes fundamentals stick.', tags: ['JavaScript', 'Functions', 'Validation'], url: 'https://github.com/cyber-Horcrux/javascript-practice-toolkit' },
  { number: '05', category: 'Interface / foundations', title: 'JS Fundamentals Login UI', description: 'A responsive glassmorphism study using validation, DOM manipulation, events, arrays, strings, functions, and regex basics.', tags: ['JavaScript', 'UI', 'Regex'], url: 'https://github.com/cyber-Horcrux/js-fundamentals-login-ui' },
  { number: '06', category: 'Early C# / .NET learning project', title: 'C# New Project', description: 'An early learning project in the C# and .NET direction — one more step from syntax toward software engineering.', tags: ['C#', '.NET', 'Learning'], url: 'https://github.com/cyber-Horcrux/CSharp-New-Project', label: 'Early C# / .NET learning project' },
];

function ProjectCard({ project, index }: { project: Project; index: number }) {
  return (
    <article className="project-card" data-cursor="EXPLORE" style={{ zIndex: index + 1 }} data-testid={`card-project-${project.number}`}>
      <div className="project-info">
        <div><div className="project-index"><span>{project.number} / 06</span><span>{project.category}</span></div><h3 className="project-title display">{project.title}</h3><p className="project-description">{project.description}</p></div>
        <div className="project-bottom"><div className="tags">{project.tags.map((tag) => <span className="tag" key={tag}>{tag}</span>)}</div><a href={project.url} target="_blank" rel="noreferrer" className="project-link" data-cursor="VIEW" data-testid={`link-project-${project.number}`}>GitHub <ArrowUpRight size={14} /></a></div>
      </div>
      <div className="project-visual" aria-label={`${project.title} typographic project preview`}><div className="visual-word">{project.title.split(' ').slice(0, 2).join(' ')}<small>{project.label ?? 'repository / study'}</small></div></div>
    </article>
  );
}

function Work() {
  return <section className="work" id="work" aria-labelledby="work-title"><div className="work-header"><div><div className="section-label">04 / selected work</div><h2 id="work-title" className="display">Projects<br />in progress</h2></div><p>Six repositories. No inflated numbers. Just the work, the lessons, and the next question.</p></div><div className="project-stack">{projects.map((project, index) => <ProjectCard project={project} index={index} key={project.number} />)}</div></section>;
}

const milestones = ['Foundation', 'C++', 'OOP', 'DSA', 'Git / GitHub', 'HTML / CSS', 'JavaScript', 'DOM', 'Responsive development', 'Web projects', 'Backend exploration', 'Linux', 'Cloud', 'DevOps', 'Future cloud engineering'];

function Journey() {
  return <section className="journey" id="journey" aria-labelledby="journey-title"><div className="section-label">05 / progression, not completion</div><h2 id="journey-title" className="display">The journey<br />so far</h2><div className="journey-track">{milestones.map((milestone, index) => { const reveal = useReveal<HTMLDivElement>(); return <div className="milestone" ref={reveal.ref} key={milestone}><strong>{milestone}</strong><span>{index < 5 ? 'the foundation layer' : index < 11 ? 'making things work' : 'looking toward systems'}</span></div>; })}</div><p className="journey-note">The line stays lit behind me. The destination stays ahead.</p></section>;
}

const topics = [
  ['Cloud computing', Cloud, 'Understanding how software moves beyond the local machine.'],
  ['DevOps', GitBranch, 'Learning the habits that connect code, people, and delivery.'],
  ['Linux', Terminal, 'Getting closer to the systems underneath the interface.'],
  ['Full-stack development', Layers, 'Following a feature from browser to backend.'],
  ['Databases', Database, 'Learning how information is structured, stored, and retrieved.'],
  ['Software engineering', Cpu, 'Turning fundamentals into dependable thinking.'],
  ['Data structures & algorithms', BookOpen, 'Practising the patterns behind clear problem solving.'],
];

function Exploring() {
  const [active, setActive] = useState(0);
  const [title, Icon] = topics[active];
  return <section className="exploring" aria-labelledby="exploring-title"><div className="section-label">06 / the present tense</div><h2 id="exploring-title" className="display">Currently<br />exploring</h2><div className="topics">{topics.map(([topic, TopicIcon], index) => <button className={`topic${active === index ? ' active' : ''}`} key={topic as string} onMouseEnter={() => setActive(index)} onFocus={() => setActive(index)} onClick={() => setActive(index)} data-testid={`button-topic-${index}`}><TopicIcon size={22} strokeWidth={1.5} /> {topic as string}</button>)}</div><div className="topic-detail"><Icon size={18} /><p><strong>{title as string}</strong><br />{topics[active][2] as string}</p></div></section>;
}

const nodes = [['CODE', Code2], ['APPLICATION', Braces], ['SERVER', Server], ['CONTAINER', Container], ['CLOUD', Cloud], ['AUTOMATION', GitBranch]] as const;
function CloudDirection() {
  return <section className="cloud" aria-labelledby="cloud-title"><div className="section-label">07 / following the system</div><h2 id="cloud-title" className="display">The direction<br />I'm heading</h2><div className="pipeline">{nodes.map(([label, Icon], index) => <div className="node" key={label}><div className="node-dot"><Icon size={16} /></div><label>{label}</label><span className="mono" style={{ fontSize: 8, color: '#8295a0' }}>0{index + 1}</span></div>)}</div><div className="direction"><h3 className="display">Cloud engineering.<br />DevOps.</h3><p>Current exploration and future goals — not a claim of completion.</p></div></section>;
}

function Education() {
  return <section className="education" aria-labelledby="education-title"><div className="section-label">08 / where the work is grounded</div><div className="education-head"><h2 id="education-title" className="display">Learning<br />in Lahore</h2><div className="education-year display">25<br /><span style={{ color: '#64737d' }}>— 29</span></div></div><div className="education-card"><div><h3>University of Management and Technology</h3><p>Bachelor's in Software Engineering<br />October 2025 – October 2029<br />Lahore, Pakistan</p><p style={{ color: '#4ccfff', marginTop: 20 }}>Academic role: Peer Tutor</p></div><div className="education-meta">{['C++', 'Object-Oriented Programming', 'Programming Fundamentals', 'Data Structures & Algorithms', 'Software Development', 'Web Technologies', 'Databases', 'Cloud Computing', 'Linux', 'Git / GitHub', 'DevOps concepts'].map((item) => <span key={item}>{item}</span>)}</div></div></section>;
}

const repos = [
  ['My-Project', 'HTML / CSS / JavaScript', 'Premium digital celebration studio'],
  ['netflix-ui-clone', 'HTML / CSS', 'Educational UI recreation'],
  ['javascript-dom-playground', 'JavaScript', 'DOM and interaction practice'],
];
function PublicCode() {
  return <section className="public-code" aria-labelledby="code-title"><div className="section-label">09 / open notebooks</div><h2 id="code-title" className="display">Built in<br />public.</h2><div className="repo-grid">{repos.map(([name, language, description]) => <a href={`https://github.com/cyber-Horcrux/${name}`} target="_blank" rel="noreferrer" className="repo" key={name} data-cursor="VIEW" data-testid={`link-repository-${name}`}><div><h3>{name}</h3><p>{description}</p></div><div className="repo-foot"><span>{language}</span><ArrowUpRight size={18} /></div></a>)}</div><a href="https://github.com/cyber-Horcrux" target="_blank" rel="noreferrer" className="github-cta" data-testid="link-github-profile">View the full GitHub profile <ArrowUpRight size={15} /></a></section>;
}

function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sent, setSent] = useState(false);
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const next: Record<string, string> = {};
    if (!form.name.trim()) next.name = 'Please add your name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next.email = 'Please enter a valid email.';
    if (form.message.trim().length < 10) next.message = 'A little more detail helps.';
    setErrors(next);
    if (!Object.keys(next).length) setSent(true);
  };
  return <section className="contact" id="contact" aria-labelledby="contact-title"><div className="section-label">10 / a final scene</div><h2 id="contact-title" className="display">Let's build<br />something.</h2><div className="contact-grid"><div><p className="contact-copy">Have an idea, project, or opportunity? Let’s connect. The email address is being finalised, so these public links are the best way to reach Wasiq for now.</p><div className="contact-links"><span className="pending">Email address pending</span><a href="https://www.linkedin.com/in/wasiq-bashir-712139399/" target="_blank" rel="noreferrer" data-testid="link-contact-linkedin">LinkedIn <ArrowUpRight size={15} /></a><a href="https://github.com/cyber-Horcrux" target="_blank" rel="noreferrer" data-testid="link-contact-github">GitHub <ArrowUpRight size={15} /></a></div></div>{sent ? <div className="success" role="status" data-testid="status-contact-success"><Check size={18} /> Your message is ready locally. No email was sent — this portfolio has no backend.</div> : <form className="contact-form" onSubmit={submit} noValidate><div className="field"><label htmlFor="contact-name">Name</label><input id="contact-name" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} data-testid="input-contact-name" />{errors.name && <span className="error-text">{errors.name}</span>}</div><div className="field"><label htmlFor="contact-email">Email</label><input id="contact-email" type="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} data-testid="input-contact-email" />{errors.email && <span className="error-text">{errors.email}</span>}</div><div className="field"><label htmlFor="contact-message">Message</label><textarea id="contact-message" value={form.message} onChange={(event) => setForm({ ...form, message: event.target.value })} data-testid="textarea-contact-message" />{errors.message && <span className="error-text">{errors.message}</span>}</div><button className="submit" type="submit" data-testid="button-contact-submit">Prepare message <Send size={15} /></button></form>}</div></section>;
}

function Footer() {
  return <footer className="footer"><div className="footer-brand">WASIQ BASHIR<span>Building the Engineer I'm Becoming.</span></div><div className="footer-right"><span>© 2026 Wasiq Bashir</span><div className="footer-socials"><a href="https://github.com/cyber-Horcrux" target="_blank" rel="noreferrer" data-testid="link-footer-github"><Github size={17} /></a><a href="https://www.linkedin.com/in/wasiq-bashir-712139399/" target="_blank" rel="noreferrer" data-testid="link-footer-linkedin"><Linkedin size={17} /></a><a href="https://www.instagram.com/the_haji_/" target="_blank" rel="noreferrer" data-testid="link-footer-instagram"><Instagram size={17} /></a></div></div></footer>;
}

function Home() {
  const [intro, setIntro] = useState(() => {
    if (typeof window === 'undefined') return true;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return false;
    return window.sessionStorage.getItem('wb-intro-seen') !== '1';
  });
  usePointerScene();
  const completeIntro = () => {
    window.sessionStorage.setItem('wb-intro-seen', '1');
    setIntro(false);
  };
  return <div className="site-shell noise">{intro && <Intro onComplete={completeIntro} />}<Cursor /><Hero /><Gallery /><About /><Building /><Work /><Journey /><Exploring /><CloudDirection /><Education /><PublicCode /><Contact /><Footer /></div>;
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route component={() => <div className="min-h-screen bg-[#0c0c0c] p-10 text-[#d7e2ea]">Page not found.</div>} /></Switch></RoutedErrorBoundary>;
}
function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}
export default App;